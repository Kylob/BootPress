# Changelog

All Notable changes to the `BootPress\Hierarchy\Component` after v1.0.0 will be documented in this file.

This project adheres to [Semantic Versioning 2.0.0](http://semver.org/spec/v2.0.0.html), and is documented using the [Keep a CHANGELOG](http://keepachangelog.com/) principles.

## [Unreleased]
