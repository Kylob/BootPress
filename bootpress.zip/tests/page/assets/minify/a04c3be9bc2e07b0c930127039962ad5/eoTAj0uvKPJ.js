jQuery.fn.vjustify=function(){var maxHeight=0;this.each(function(){if(this.offsetHeight>maxHeight){maxHeight=this.offsetHeight}});this.each(function(){$(this).height(maxHeight+"px");if(this.offsetHeight>maxHeight){$(this).height((maxHeight-(this.offsetHeight-maxHeight))+"px")}})};var s=80;var fs=1;var fb=30;var st="*";var br=5;var bt=70;var cl=new Array("aaffee","ccff77","ffcc44","ffaa22","ffbb66","ffff88")
var nc=6;var fm=!0;var bl=0;var bi=0;var a=s/2;blink=setInterval('blinker(0,0)',br);clearInterval(blink);function add(x,y){clearInterval(blink);document.all.planet.style.visibility="visible";to=x;le=y;blink=setInterval('blinker(to,le)',br);bl=0}
function fallow(x,y){to=x;le=y;clearInterval(blink);blink=setInterval('blinker(to,le)',br)}
function blinker(x,y){if(fm==!0)
document.onmousemove=new Function("fallow(event.x,event.y);return false")
c=Math.floor(Math.random()*s);d=Math.floor(Math.random()*s);f=Math.floor(Math.floor(Math.random()*(fb-fs+1)+fs));document.all.planet.style.color=cl[bi];document.all.planet.style.font=f+"px;";document.all.planet.style.left=x-c+a;document.all.planet.style.top=y-d+a;bl=bl+1;bi=bi+1;if(bi==nc){bi=0}
if(bl==bt){clearInterval(blink);document.all.planet.style.visibility="hidden";document.all.planet.style.left=-s;document.all.planet.style.top=-s;document.all.planet.style.color=000000;document.all.planet.style.font=1+"px;";document.onmousemove=new Function("return false")
bl=0}}
document.oncontextmenu=new Function("add(event.x,event.y);return false")
document.write("<span id=planet style=visibility:hidden;position:absolute;top:-80px;left:-80px>"+st+"</span>")