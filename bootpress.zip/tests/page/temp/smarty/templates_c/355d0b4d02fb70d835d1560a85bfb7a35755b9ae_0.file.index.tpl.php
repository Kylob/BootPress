<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:15:31
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\content\category\subcategory\flowery-post\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34e0335d786_77917797',
  'file_dependency' => 
  array (
    '355d0b4d02fb70d835d1560a85bfb7a35755b9ae' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\content\\category\\subcategory\\flowery-post\\index.tpl',
      1 => 1458753364,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34e0335d786_77917797 ($_smarty_tpl) {
?>


<?php echo $_smarty_tpl->tpl_vars['page']->value->title;?>


<img src="<?php echo $_smarty_tpl->tpl_vars['page']->value->url('folder','flowers.jpg');?>
">

Aren't they beautiful?<?php }
}
