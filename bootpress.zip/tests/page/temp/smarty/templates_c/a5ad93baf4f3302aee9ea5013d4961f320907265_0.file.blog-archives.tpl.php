<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:18:08
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\themes\blog-archives.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34ea09fbfa1_41523567',
  'file_dependency' => 
  array (
    'a5ad93baf4f3302aee9ea5013d4961f320907265' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\themes\\blog-archives.tpl',
      1 => 1470320273,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34ea09fbfa1_41523567 ($_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['bp']->value->breadcrumbs($_smarty_tpl->tpl_vars['breadcrumbs']->value);?>


<?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>"The Archives at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"All of the blog posts at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']).".  Archived in the order they were received."));?>


<h2>The Archives</h2>

<?php
$_from = $_smarty_tpl->tpl_vars['archives']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_years_0_saved_item = isset($_smarty_tpl->tpl_vars['years']) ? $_smarty_tpl->tpl_vars['years'] : false;
$__foreach_years_0_saved_key = isset($_smarty_tpl->tpl_vars['Y']) ? $_smarty_tpl->tpl_vars['Y'] : false;
$_smarty_tpl->tpl_vars['years'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['Y'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['years']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['Y']->value => $_smarty_tpl->tpl_vars['years']->value) {
$_smarty_tpl->tpl_vars['years']->_loop = true;
$__foreach_years_0_saved_local_item = $_smarty_tpl->tpl_vars['years'];
?>
    <h3><a href="<?php echo $_smarty_tpl->tpl_vars['years']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['Y']->value;?>
</a> <?php echo $_smarty_tpl->tpl_vars['bp']->value->label('primary',$_smarty_tpl->tpl_vars['years']->value['count']);?>
</h3>
    <?php $_smarty_tpl->tpl_vars['columns'] = new Smarty_Variable(array(), null);
$_smarty_tpl->ext->_updateScope->updateScope($_smarty_tpl, 'columns', 0);?>
    <?php
$_from = $_smarty_tpl->tpl_vars['years']->value['months'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_months_1_saved_item = isset($_smarty_tpl->tpl_vars['months']) ? $_smarty_tpl->tpl_vars['months'] : false;
$__foreach_months_1_saved_key = isset($_smarty_tpl->tpl_vars['M']) ? $_smarty_tpl->tpl_vars['M'] : false;
$_smarty_tpl->tpl_vars['months'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['M'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['months']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['M']->value => $_smarty_tpl->tpl_vars['months']->value) {
$_smarty_tpl->tpl_vars['months']->_loop = true;
$__foreach_months_1_saved_local_item = $_smarty_tpl->tpl_vars['months'];
?>
        <?php ob_start();
if ($_smarty_tpl->tpl_vars['months']->value['count'] > 0) {
echo " <br> ";
echo (string)$_smarty_tpl->tpl_vars['bp']->value->label('primary',$_smarty_tpl->tpl_vars['months']->value['count']);
echo " ";
}
$_tmp5=ob_get_clean();
$_smarty_tpl->smarty->ext->_var->createLocalArrayVariable($_smarty_tpl, 'columns', null);
$_smarty_tpl->tpl_vars['columns']->value[] = $_smarty_tpl->tpl_vars['bp']->value->col('1 text-center',$_smarty_tpl->tpl_vars['bp']->value->button('link block',((string)$_smarty_tpl->tpl_vars['M']->value)." ".$_tmp5,array('href'=>$_smarty_tpl->tpl_vars['months']->value['url'])));
$_smarty_tpl->ext->_updateScope->updateScope($_smarty_tpl, 'columns', 0);?>
    <?php
$_smarty_tpl->tpl_vars['months'] = $__foreach_months_1_saved_local_item;
}
if ($__foreach_months_1_saved_item) {
$_smarty_tpl->tpl_vars['months'] = $__foreach_months_1_saved_item;
}
if ($__foreach_months_1_saved_key) {
$_smarty_tpl->tpl_vars['M'] = $__foreach_months_1_saved_key;
}
?>
    <?php echo $_smarty_tpl->tpl_vars['bp']->value->row('sm',$_smarty_tpl->tpl_vars['columns']->value);?>

    <br>
<?php
$_smarty_tpl->tpl_vars['years'] = $__foreach_years_0_saved_local_item;
}
if ($__foreach_years_0_saved_item) {
$_smarty_tpl->tpl_vars['years'] = $__foreach_years_0_saved_item;
}
if ($__foreach_years_0_saved_key) {
$_smarty_tpl->tpl_vars['Y'] = $__foreach_years_0_saved_key;
}
}
}
