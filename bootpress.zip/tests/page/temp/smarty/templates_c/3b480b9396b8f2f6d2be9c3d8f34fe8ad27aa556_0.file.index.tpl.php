<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:15:33
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\content\uncategorized-post\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34e05208838_45340070',
  'file_dependency' => 
  array (
    '3b480b9396b8f2f6d2be9c3d8f34fe8ad27aa556' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\content\\uncategorized-post\\index.tpl',
      1 => 1457746956,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34e05208838_45340070 ($_smarty_tpl) {
?>


A post without a category<?php }
}
