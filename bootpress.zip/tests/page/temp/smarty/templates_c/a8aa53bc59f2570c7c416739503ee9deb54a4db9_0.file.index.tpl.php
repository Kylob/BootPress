<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:15:28
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\content\category\subcategory\featured-post\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34e00421820_50372599',
  'file_dependency' => 
  array (
    'a8aa53bc59f2570c7c416739503ee9deb54a4db9' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\content\\category\\subcategory\\featured-post\\index.tpl',
      1 => 1458243837,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34e00421820_50372599 ($_smarty_tpl) {
?>


1. One
2. Two
3. Three<?php }
}
