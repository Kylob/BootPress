<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:18:57
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\themes\blog-tags.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34ed19b90e5_56926754',
  'file_dependency' => 
  array (
    '9b09b227287b77205b3e79a60ea36846ccf45a89' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\themes\\blog-tags.tpl',
      1 => 1470320323,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34ed19b90e5_56926754 ($_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['bp']->value->breadcrumbs($_smarty_tpl->tpl_vars['breadcrumbs']->value);?>


<?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>"Tag Cloud at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"View the most frequently used tags at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])));?>


<h2>Tag Cloud</h2>

<p>

    <?php
$_from = $_smarty_tpl->tpl_vars['tags']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_tag_0_saved_item = isset($_smarty_tpl->tpl_vars['tag']) ? $_smarty_tpl->tpl_vars['tag'] : false;
$_smarty_tpl->tpl_vars['tag'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['tag']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['tag']->value) {
$_smarty_tpl->tpl_vars['tag']->_loop = true;
$__foreach_tag_0_saved_local_item = $_smarty_tpl->tpl_vars['tag'];
?>
        <?php if ($_smarty_tpl->tpl_vars['tag']->value['rank'] == 1) {?>
            <a class="text-primary" style="font-size:15px; padding:0px 5px;" href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
        <?php } elseif ($_smarty_tpl->tpl_vars['tag']->value['rank'] == 2) {?>
            <a class="text-info" style="font-size:18px; padding:0px 5px;" href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
        <?php } elseif ($_smarty_tpl->tpl_vars['tag']->value['rank'] == 3) {?>
            <a class="text-success" style="font-size:21px; padding:0px 5px;" href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
        <?php } elseif ($_smarty_tpl->tpl_vars['tag']->value['rank'] == 4) {?>
            <a class="text-warning" style="font-size:24px; padding:0px 5px;" href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
        <?php } else { ?>
            <a class="text-danger" style="font-size:27px; padding:0px 5px;" href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
        <?php }?>
    <?php
$_smarty_tpl->tpl_vars['tag'] = $__foreach_tag_0_saved_local_item;
}
if ($__foreach_tag_0_saved_item) {
$_smarty_tpl->tpl_vars['tag'] = $__foreach_tag_0_saved_item;
}
?>
  
</p>
<?php }
}
