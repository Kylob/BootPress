<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:18:34
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\themes\blog-authors.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34eba11f9e3_66033164',
  'file_dependency' => 
  array (
    'de7d37312a70f766e16aa5995c4736f7dfac9e08' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\themes\\blog-authors.tpl',
      1 => 1470320307,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34eba11f9e3_66033164 ($_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['bp']->value->breadcrumbs($_smarty_tpl->tpl_vars['breadcrumbs']->value);?>


<?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>"Authors at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"View all of the authors who have submitted blog posts at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])));?>


<h2>Authors</h2>

<?php
$_from = $_smarty_tpl->tpl_vars['authors']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_author_0_saved_item = isset($_smarty_tpl->tpl_vars['author']) ? $_smarty_tpl->tpl_vars['author'] : false;
$_smarty_tpl->tpl_vars['author'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['author']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['author']->value) {
$_smarty_tpl->tpl_vars['author']->_loop = true;
$__foreach_author_0_saved_local_item = $_smarty_tpl->tpl_vars['author'];
?>
    <p><a href="<?php echo $_smarty_tpl->tpl_vars['author']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['author']->value['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['bp']->value->badge($_smarty_tpl->tpl_vars['author']->value['count']);?>
</a></p>
<?php
$_smarty_tpl->tpl_vars['author'] = $__foreach_author_0_saved_local_item;
}
if ($__foreach_author_0_saved_item) {
$_smarty_tpl->tpl_vars['author'] = $__foreach_author_0_saved_item;
}
}
}
