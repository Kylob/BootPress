<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:15:25
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\content\about\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34dfda8b968_91087662',
  'file_dependency' => 
  array (
    'b674506707cab36290cde399bd4205c710e2fd1c' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\content\\about\\index.tpl',
      1 => 1457735553,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34dfda8b968_91087662 ($_smarty_tpl) {
?>


This is my website.<?php }
}
