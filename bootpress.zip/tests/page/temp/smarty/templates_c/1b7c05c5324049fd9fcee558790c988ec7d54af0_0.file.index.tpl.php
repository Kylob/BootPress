<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:15:32
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\content\index\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34e044c46a1_05237444',
  'file_dependency' => 
  array (
    '1b7c05c5324049fd9fcee558790c988ec7d54af0' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\content\\index\\index.tpl',
      1 => 1458245950,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34e044c46a1_05237444 ($_smarty_tpl) {
?>


This is the index page.<?php }
}
