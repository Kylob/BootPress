<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:19:19
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\themes\blog-feed.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34ee7391b96_86009930',
  'file_dependency' => 
  array (
    'e1f3b8e06f7a3f9b94d1c97f0c2f450b698fd3d3' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\themes\\blog-feed.tpl',
      1 => 1470320350,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34ee7391b96_86009930 ($_smarty_tpl) {
echo '<?xml ';?>
version="1.0"<?php echo '?>';?>

<rss version="2.0">
<channel>
    <title><?php echo $_smarty_tpl->tpl_vars['blog']->value['name'];?>
</title>
    <link><?php echo $_smarty_tpl->tpl_vars['page']->value->url('blog');?>
</link>
    <description><?php echo $_smarty_tpl->tpl_vars['blog']->value['summary'];?>
</description>
    
    <?php echo $_smarty_tpl->tpl_vars['bp']->value->pagination->set('page',20);?>

    <?php
$_from = $_smarty_tpl->tpl_vars['page']->value->blog($_smarty_tpl->tpl_vars['listings']->value,$_smarty_tpl->tpl_vars['bp']->value->pagination);
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_post_0_saved_item = isset($_smarty_tpl->tpl_vars['post']) ? $_smarty_tpl->tpl_vars['post'] : false;
$_smarty_tpl->tpl_vars['post'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['post']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['post']->value) {
$_smarty_tpl->tpl_vars['post']->_loop = true;
$__foreach_post_0_saved_local_item = $_smarty_tpl->tpl_vars['post'];
?>
        <item>
            <title><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</title>
            <link><?php echo $_smarty_tpl->tpl_vars['post']->value['url'];?>
</link>
            <description><![CDATA[<?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>
]]></description>
            <pubDate><?php echo date(DateTime::RFC2822,$_smarty_tpl->tpl_vars['post']->value['published']);?>
</pubDate>
            <guid isPermaLink="true"><?php echo $_smarty_tpl->tpl_vars['post']->value['url'];?>
</guid>
        </item>
    <?php
$_smarty_tpl->tpl_vars['post'] = $__foreach_post_0_saved_local_item;
}
if ($__foreach_post_0_saved_item) {
$_smarty_tpl->tpl_vars['post'] = $__foreach_post_0_saved_item;
}
?>
    
</channel>
</rss>
<?php }
}
