<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:17:17
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\themes\blog-listings.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34e6d48a0c6_81619136',
  'file_dependency' => 
  array (
    '699cd52611d36355150f279a03928f58ba9d95d9' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\themes\\blog-listings.tpl',
      1 => 1470320179,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34e6d48a0c6_81619136 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\smarty\\smarty\\libs\\plugins\\modifier.date_format.php';
if ($_smarty_tpl->tpl_vars['blog']->value['page'] != 'index') {?> <?php echo $_smarty_tpl->tpl_vars['bp']->value->breadcrumbs($_smarty_tpl->tpl_vars['breadcrumbs']->value);?>
 <?php }?>

<?php if ($_smarty_tpl->tpl_vars['search']->value) {?>

    <?php if ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'index') {?>
        
        <?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>"Search for '".((string)$_smarty_tpl->tpl_vars['search']->value)."' at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"All of the search results at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])." for '".((string)$_smarty_tpl->tpl_vars['search']->value)."'"));?>

        
    <?php } elseif ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'category') {?>
        
        <?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>("Search for '".((string)$_smarty_tpl->tpl_vars['search']->value)."' in ").(implode(' &raquo; ',$_smarty_tpl->tpl_vars['category']->value)),'description'=>("All of the search results for '".((string)$_smarty_tpl->tpl_vars['search']->value)."' in ").(implode(' &raquo; ',$_smarty_tpl->tpl_vars['category']->value))));?>

        
    <?php }?>

    <h2>Search Results for '<?php echo $_smarty_tpl->tpl_vars['search']->value;?>
'</h2>

<?php } elseif ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'index') {?>

    <?php ob_start();
if (!empty($_smarty_tpl->tpl_vars['blog']->value['summary'])) {
echo " ";
echo (string)$_smarty_tpl->tpl_vars['blog']->value['summary'];
echo " ";
} else {
echo " View all of the posts at ";
echo (string)$_smarty_tpl->tpl_vars['blog']->value['name'];
echo " ";
}
$_tmp1=ob_get_clean();
echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>$_tmp1));?>

    
    <h2>Blog Posts</h2>

<?php } elseif ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'category') {?>

    <?php ob_start();
echo implode(' &raquo; ',$_smarty_tpl->tpl_vars['category']->value);
$_tmp2=ob_get_clean();
ob_start();
echo implode(' &raquo; ',$_smarty_tpl->tpl_vars['category']->value);
$_tmp3=ob_get_clean();
echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>$_tmp2." at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"View all of the posts at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])." that have been categorized under ".$_tmp3));?>

    
    <h2><?php echo implode(' &raquo; ',$_smarty_tpl->tpl_vars['category']->value);?>
 Posts</h2>

<?php } elseif ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'archives') {?>
    
    <?php if (count($_smarty_tpl->tpl_vars['archive']->value) == 4) {?>
        <?php $_smarty_tpl->tpl_vars['date'] = new Smarty_Variable(smarty_modifier_date_format($_smarty_tpl->tpl_vars['archive']->value['date'],'F j, Y'), null);
$_smarty_tpl->ext->_updateScope->updateScope($_smarty_tpl, 'date', 0);?>
    <?php } elseif (count($_smarty_tpl->tpl_vars['archive']->value) == 3) {?>
        <?php $_smarty_tpl->tpl_vars['date'] = new Smarty_Variable(smarty_modifier_date_format($_smarty_tpl->tpl_vars['archive']->value['date'],'F Y'), null);
$_smarty_tpl->ext->_updateScope->updateScope($_smarty_tpl, 'date', 0);?>
    <?php } elseif (count($_smarty_tpl->tpl_vars['archive']->value) == 2) {?>
        <?php $_smarty_tpl->tpl_vars['date'] = new Smarty_Variable(smarty_modifier_date_format($_smarty_tpl->tpl_vars['archive']->value['date'],'Y'), null);
$_smarty_tpl->ext->_updateScope->updateScope($_smarty_tpl, 'date', 0);?>
    <?php }?>
    
    <?php ob_start();
if (count($_smarty_tpl->tpl_vars['archive']->value) == 4) {
echo " on ";
} else {
echo " in ";
}
$_tmp4=ob_get_clean();
echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>((string)$_smarty_tpl->tpl_vars['date']->value)." Archives at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"All of the blog posts at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])." that were published".$_tmp4.((string)$_smarty_tpl->tpl_vars['date']->value)));?>

    
    <h2><?php echo $_smarty_tpl->tpl_vars['date']->value;?>
 Archives</h2>
    
<?php } elseif ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'authors') {?>

    <?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>((string)$_smarty_tpl->tpl_vars['author']->value['name'])." at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"All of the blog posts at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])." that have been submitted by ".((string)$_smarty_tpl->tpl_vars['author']->value['name'])));?>

    
    <h2>Author: <?php echo $_smarty_tpl->tpl_vars['author']->value['name'];?>
</h2>

<?php } elseif ($_smarty_tpl->tpl_vars['blog']->value['page'] == 'tags') {?>

    <?php echo $_smarty_tpl->tpl_vars['page']->value->set(array('title'=>((string)$_smarty_tpl->tpl_vars['tag']->value['name'])." at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name']),'description'=>"Everything at ".((string)$_smarty_tpl->tpl_vars['blog']->value['name'])." that has been tagged with '".((string)$_smarty_tpl->tpl_vars['tag']->value['name'])."'"));?>

    
    <h2>Tag: <?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</h2>

<?php }?>

<?php if (!$_smarty_tpl->tpl_vars['bp']->value->pagination->set('page',10)) {?>
    <?php echo $_smarty_tpl->tpl_vars['bp']->value->pagination->total($_smarty_tpl->tpl_vars['page']->value->blog($_smarty_tpl->tpl_vars['listings']->value,'count'));?>

<?php }?>

<?php
$_from = $_smarty_tpl->tpl_vars['page']->value->blog($_smarty_tpl->tpl_vars['listings']->value,$_smarty_tpl->tpl_vars['bp']->value->pagination);
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_post_0_saved_item = isset($_smarty_tpl->tpl_vars['post']) ? $_smarty_tpl->tpl_vars['post'] : false;
$_smarty_tpl->tpl_vars['post'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['post']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['post']->value) {
$_smarty_tpl->tpl_vars['post']->_loop = true;
$__foreach_post_0_saved_local_item = $_smarty_tpl->tpl_vars['post'];
?>
    <p itemscope itemtype="http://schema.org/Article">
        <big itemprop="name"><a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</a></big>
        <?php if ($_smarty_tpl->tpl_vars['search']->value) {?>
            <br><?php echo $_smarty_tpl->tpl_vars['post']->value['snippet'];?>

        <?php } elseif (!empty($_smarty_tpl->tpl_vars['post']->value['description'])) {?>
            <br><span itemprop="headline"><?php echo $_smarty_tpl->tpl_vars['post']->value['description'];?>
</span>
        <?php }?>
    </p>
<?php
$_smarty_tpl->tpl_vars['post'] = $__foreach_post_0_saved_local_item;
}
if ($__foreach_post_0_saved_item) {
$_smarty_tpl->tpl_vars['post'] = $__foreach_post_0_saved_item;
}
?>

<?php echo $_smarty_tpl->tpl_vars['bp']->value->pagination->pager();?>

<?php }
}
