<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:19:29
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\content\category\unpublished-post\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34ef18d2782_28985973',
  'file_dependency' => 
  array (
    '9770501dddf4a28afcd19c4d21c6185d7aca9488' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\content\\category\\unpublished-post\\index.tpl',
      1 => 1470320367,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34ef18d2782_28985973 ($_smarty_tpl) {
?>


Hello Smarty Pants<?php }
}
