<?php
/* Smarty version 3.1.29, created on 2016-08-04 15:15:53
  from "C:\Users\Kyle\Desktop\UniServerZ\www\composer\vendor\bootpress\components\tests\page\blog\themes\blog-post.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57a34e191acb73_69820123',
  'file_dependency' => 
  array (
    '775e70dee66a730c545621a9ab20865378f63264' => 
    array (
      0 => 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\bootpress\\components\\tests\\page\\blog\\themes\\blog-post.tpl',
      1 => 1470320137,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57a34e191acb73_69820123 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'C:\\Users\\Kyle\\Desktop\\UniServerZ\\www\\composer\\vendor\\smarty\\smarty\\libs\\plugins\\modifier.date_format.php';
if ($_smarty_tpl->tpl_vars['post']->value['page']) {?>

    <?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>


<?php } else { ?>

    <div itemscope itemtype="http://schema.org/Article">
    
        <div class="page-header"><h1 itemprop="name"><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</h1></div><br>
        
        <div itemprop="articleBody" style="padding-bottom:40px;"><?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>
</div>
        
        <?php
$_from = $_smarty_tpl->tpl_vars['post']->value['tags'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_tag_0_saved_item = isset($_smarty_tpl->tpl_vars['tag']) ? $_smarty_tpl->tpl_vars['tag'] : false;
$__foreach_tag_0_total = $_smarty_tpl->smarty->ext->_foreach->count($_from);
$_smarty_tpl->tpl_vars['tag'] = new Smarty_Variable();
$__foreach_tag_0_first = true;
$__foreach_tag_0_iteration=0;
$_smarty_tpl->tpl_vars['tag']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['tag']->value) {
$_smarty_tpl->tpl_vars['tag']->_loop = true;
$__foreach_tag_0_iteration++;
$_smarty_tpl->tpl_vars['tag']->first = $__foreach_tag_0_first;
$_smarty_tpl->tpl_vars['tag']->last = $__foreach_tag_0_iteration == $__foreach_tag_0_total;
$__foreach_tag_0_first = false;
$__foreach_tag_0_saved_local_item = $_smarty_tpl->tpl_vars['tag'];
?>
            <?php if ($_smarty_tpl->tpl_vars['tag']->first) {?> <p>Tagged: <?php }?>
            &nbsp;<a href="<?php echo $_smarty_tpl->tpl_vars['tag']->value['url'];?>
" itemprop="keywords"><?php echo $_smarty_tpl->tpl_vars['tag']->value['name'];?>
</a>
            <?php if ($_smarty_tpl->tpl_vars['tag']->last) {?> </p> <?php }?>
        <?php
$_smarty_tpl->tpl_vars['tag'] = $__foreach_tag_0_saved_local_item;
}
if ($__foreach_tag_0_saved_item) {
$_smarty_tpl->tpl_vars['tag'] = $__foreach_tag_0_saved_item;
}
?>
        
        <p>
            <?php if (!empty($_smarty_tpl->tpl_vars['post']->value['published'])) {?> Published: <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['archive'];?>
" itemprop="datePublished"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['post']->value['published'],'%B %e, %Y');?>
</a> <?php }?>
            <?php if (!empty($_smarty_tpl->tpl_vars['post']->value['author'])) {?> by <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['author']['url'];?>
" itemprop="author"><?php echo $_smarty_tpl->tpl_vars['post']->value['author']['name'];?>
</a> <?php }?>
        </p>
        
    </div>
    
    <?php echo $_smarty_tpl->tpl_vars['bp']->value->pagination->pager($_smarty_tpl->tpl_vars['post']->value['previous'],$_smarty_tpl->tpl_vars['post']->value['next']);?>

    
<?php }
}
}
